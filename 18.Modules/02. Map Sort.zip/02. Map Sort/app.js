let mapSort = require('./mapSort');

//let map = new Map();
//map.set(3,"Pesho");
//map.set(1,"Gosho");
//map.set(7,"Aleks");
//console.log(mapSort(map));


result.mapSort = mapSort;