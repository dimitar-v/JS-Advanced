let Entity = require("./entity");
let Dog = require("./dog");
let Person = require("./person");
let Student = require("./student");

//let d = new Dog('Sparky');
//console.log(d.saySomething());
//
//let p = new Person('Pesho', 'Haha ha :P', d);
//console.log(p.saySomething());
//
//console.log();
//let s = new Student('Pesho', 'Haha ha :P', d, 123456);
//console.log(s.saySomething());

result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;